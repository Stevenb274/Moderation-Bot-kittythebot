exports.Prefix = `K!`;
exports.Color = `RANDOM`;

//Put the Token in Client secrets LOCK Button
